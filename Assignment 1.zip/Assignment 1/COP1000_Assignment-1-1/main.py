print("I'm learning how to program in Python.")
print("That's awesome!")